class Foo {
  test() {
  }

  title(arg) {
  }
}

class Bar {
}
