### class: Bar

### class: Foo

#### foo.test()

#### foo.test()

#### foo.title(arg, arg)
- `arg` <[number]>
- `arg` <[number]>

### class: Bar

