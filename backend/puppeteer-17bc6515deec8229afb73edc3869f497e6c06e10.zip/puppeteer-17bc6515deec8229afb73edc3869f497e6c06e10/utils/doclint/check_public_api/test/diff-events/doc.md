### class: Foo

#### event: 'start'

#### event: 'stop'
