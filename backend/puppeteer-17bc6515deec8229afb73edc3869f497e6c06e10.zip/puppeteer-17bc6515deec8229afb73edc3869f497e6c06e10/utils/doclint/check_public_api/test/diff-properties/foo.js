class Foo {
  constructor() {
    this.a = 42;
    this.b = 'hello';
    this.emit('done');
  }
}
